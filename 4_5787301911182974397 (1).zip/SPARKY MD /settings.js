const settings = {
  packname: 'Meta Tech',
  author: 'Lord Sparky',
  botName: "Sparky MD",
  botOwner: 'Dev Sparky', // Your name
  ownerNumber: '2347076778367', //Set your number here without + symbol.
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.0",
};

module.exports = settings;
