module.exports = {
  BOT_TOKEN: '8730037275:AAFUuZ05poKNWdJ6kxu2um5gfXlb7CQUREo',  
  startupPassword: 'sparky'
};