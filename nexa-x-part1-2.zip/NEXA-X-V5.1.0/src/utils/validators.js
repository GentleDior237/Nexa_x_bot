// Small input checks shared by Telegram and WhatsApp commands.

// Only these characters may be used in a WhatsApp prefix.
// Letters/digits are blocked (they would clash with normal text and commands).
// * _ ~ ` @ and quotes are blocked (they clash with WhatsApp text formatting/mentions).
const ALLOWED_PREFIX_CHARS = new Set('.!#$%&+-=?^|,;:/\\<>'.split(''));

export function validatePrefix(input) {
  const prefix = String(input ?? '');
  if (prefix.length < 1 || prefix.length > 2) {
    return { ok: false, reason: 'A prefix must be 1 or 2 characters long.' };
  }
  for (const ch of prefix) {
    if (!ALLOWED_PREFIX_CHARS.has(ch)) {
      return {
        ok: false,
        reason: `"${ch}" is not allowed. Use symbols such as . ! # $ % & + - = ? ^ | , ; : / < >`,
      };
    }
  }
  return { ok: true, value: prefix };
}

export const MENU_STYLES = [
  'compact', 'box', 'slanted', 'long', 'minimal', 'premium', 'cyber', 'classic',
];

export function validateMenuStyle(input) {
  const style = String(input ?? '').trim().toLowerCase();
  return MENU_STYLES.includes(style)
    ? { ok: true, value: style }
    : { ok: false, reason: `Menu style must be one of: ${MENU_STYLES.join(', ')}` };
}
