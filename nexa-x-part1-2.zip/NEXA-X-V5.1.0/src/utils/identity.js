// Helpers that turn messy IDs into one clean, comparable form.
// Rule: identity is ALWAYS a number/JID, never a username or display name.

/** Telegram IDs are stored as plain digit strings, e.g. "123456789". */
export function normalizeTelegramId(input) {
  const value = String(input ?? '').trim();
  return /^\d{1,20}$/.test(value) ? value : null;
}

/**
 * Turns a phone number or any WhatsApp ID form into the whatsapp-web.js form.
 *   "2348012345678"                  -> "2348012345678@c.us"
 *   "2348012345678@s.whatsapp.net"   -> "2348012345678@c.us"
 *   "2348012345678:12@c.us"          -> "2348012345678@c.us"  (device part removed)
 *   "123456789@lid"                  -> "123456789@lid"       (kept as is)
 *   "1203630-1234@g.us"              -> kept as is (group)
 * Returns null when the input cannot be trusted.
 */
export function normalizeWhatsAppJid(input) {
  const raw = String(input ?? '').trim();
  if (!raw) return null;

  if (!raw.includes('@')) {
    const digits = raw.replace(/[\s+()-]/g, '');
    return /^\d{7,15}$/.test(digits) ? `${digits}@c.us` : null;
  }

  const [userPart, server] = raw.split('@');
  const user = userPart.split(':')[0];

  if (server === 'g.us') return /^[\d-]{5,40}$/.test(user) ? `${user}@g.us` : null;
  if (server === 'lid') return /^\d{5,30}$/.test(user) ? `${user}@lid` : null;
  if (server === 'c.us' || server === 's.whatsapp.net') {
    return /^\d{7,15}$/.test(user) ? `${user}@c.us` : null;
  }
  return null;
}

/** Returns the phone number (digits only) from a normal user JID, else null. */
export function phoneFromJid(jid) {
  const normalized = normalizeWhatsAppJid(jid);
  return normalized && normalized.endsWith('@c.us') ? normalized.split('@')[0] : null;
}
