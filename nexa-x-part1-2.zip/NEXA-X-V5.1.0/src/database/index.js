import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const MIGRATIONS_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'migrations');

/** Opens the real SQLite file using better-sqlite3. */
export async function openDatabase(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const { default: Database } = await import('better-sqlite3');
  const db = new Database(filePath);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA foreign_keys = ON');
  db.exec('PRAGMA busy_timeout = 5000');
  return db;
}

// Remembers how deep we are inside transactions for each database.
const depthByDb = new WeakMap();

/**
 * Runs fn() as ONE all-or-nothing step.
 * If fn throws, every change it made is undone.
 * BEGIN IMMEDIATE locks the database for writing straight away, so two
 * pairing requests can never both pass the capacity check at the same time.
 */
export function withTransaction(db, fn) {
  const depth = depthByDb.get(db) ?? 0;
  if (depth > 0) return fn(); // already inside a transaction

  db.exec('BEGIN IMMEDIATE');
  depthByDb.set(db, 1);
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch { /* nothing to undo */ }
    throw error;
  } finally {
    depthByDb.set(db, 0);
  }
}

/** Applies every migration file that has not been applied yet. Safe to run on every start. */
export async function runMigrations(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);

  const applied = new Set(
    db.prepare('SELECT id FROM schema_migrations').all().map((row) => row.id),
  );

  const files = fs.readdirSync(MIGRATIONS_DIR).filter((f) => /^\d+_.+\.js$/.test(f)).sort();
  const newlyApplied = [];

  for (const file of files) {
    const migration = (await import(pathToFileURL(path.join(MIGRATIONS_DIR, file)).href)).default;
    if (applied.has(migration.id)) continue;

    withTransaction(db, () => {
      migration.up(db);
      db.prepare('INSERT INTO schema_migrations (id, name) VALUES (?, ?)').run(migration.id, migration.name);
    });
    newlyApplied.push(migration.name);
  }
  return newlyApplied;
}
