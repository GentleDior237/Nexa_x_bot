const CAPACITY_KEY = 'pairing_capacity';
const MAX_CAPACITY = 10000;

export function createGlobalSettingsRepository(db, { defaultCapacity }) {
  function get(key) {
    return db.prepare('SELECT value FROM global_settings WHERE key = ?').get(key)?.value;
  }
  function set(key, value) {
    db.prepare(`
      INSERT INTO global_settings (key, value) VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')
    `).run(key, String(value));
  }

  return {
    get,
    set,

    /** The owner-set capacity, or MAX_SESSIONS from .env if the owner never changed it. */
    getPairingCapacity() {
      const stored = Number.parseInt(get(CAPACITY_KEY) ?? '', 10);
      return Number.isInteger(stored) && stored >= 0 ? stored : defaultCapacity;
    },

    setPairingCapacity(value) {
      const number = Number(value);
      if (!Number.isInteger(number) || number < 0 || number > MAX_CAPACITY) {
        return { ok: false, reason: `Capacity must be a whole number from 0 to ${MAX_CAPACITY}.` };
      }
      set(CAPACITY_KEY, number);
      return { ok: true, capacity: number };
    },

    /** Add (positive) or remove (negative) capacity. */
    adjustPairingCapacity(delta) {
      return this.setPairingCapacity(this.getPairingCapacity() + Number(delta));
    },
  };
}
