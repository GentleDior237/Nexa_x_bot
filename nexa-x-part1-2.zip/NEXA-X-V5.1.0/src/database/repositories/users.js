import { normalizeTelegramId, normalizeWhatsAppJid, phoneFromJid } from '../../utils/identity.js';

export function createUserRepositories(db) {
  const telegram = {
    /** Adds the user, or refreshes name/username and last_seen. */
    upsert({ id, firstName = '', username = null }) {
      const telegramId = normalizeTelegramId(id);
      if (!telegramId) throw new Error('Invalid Telegram ID.');
      db.prepare(`
        INSERT INTO telegram_users (telegram_id, first_name, username)
        VALUES (?, ?, ?)
        ON CONFLICT(telegram_id) DO UPDATE SET
          first_name = excluded.first_name,
          username   = excluded.username,
          last_seen  = datetime('now')
      `).run(telegramId, String(firstName).slice(0, 100), username ? String(username).slice(0, 64) : null);
      return this.get(telegramId);
    },
    get(id) {
      const telegramId = normalizeTelegramId(id);
      return telegramId
        ? db.prepare('SELECT * FROM telegram_users WHERE telegram_id = ?').get(telegramId)
        : undefined;
    },
    count() {
      return db.prepare('SELECT COUNT(*) AS n FROM telegram_users').get().n;
    },
  };

  const whatsapp = {
    upsert({ jid, pushName = null }) {
      const normalized = normalizeWhatsAppJid(jid);
      if (!normalized) throw new Error('Invalid WhatsApp ID.');
      db.prepare(`
        INSERT INTO whatsapp_users (jid, phone, push_name)
        VALUES (?, ?, ?)
        ON CONFLICT(jid) DO UPDATE SET
          push_name = COALESCE(excluded.push_name, whatsapp_users.push_name),
          last_seen = datetime('now')
      `).run(normalized, phoneFromJid(normalized), pushName ? String(pushName).slice(0, 100) : null);
      return this.get(normalized);
    },
    get(jid) {
      const normalized = normalizeWhatsAppJid(jid);
      return normalized
        ? db.prepare('SELECT * FROM whatsapp_users WHERE jid = ?').get(normalized)
        : undefined;
    },
  };

  return { telegram, whatsapp };
}
