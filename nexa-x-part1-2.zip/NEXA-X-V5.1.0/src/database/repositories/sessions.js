import crypto from 'node:crypto';
import { withTransaction } from '../index.js';
import { normalizeTelegramId } from '../../utils/identity.js';

const SESSION_ID_PATTERN = /^wa_[0-9a-f]{12}$/;
const STATUSES = ['pending', 'pairing', 'connected', 'disconnected'];

/** The ID is also used as a folder name later, so it must be strictly checked. */
export function isValidSessionId(id) {
  return typeof id === 'string' && SESSION_ID_PATTERN.test(id);
}

export function createSessionRepository(db, { getCapacity, defaultPrefix }) {
  const repo = {
    count() {
      return db.prepare('SELECT COUNT(*) AS n FROM wa_sessions').get().n;
    },

    get(id) {
      return isValidSessionId(id) ? db.prepare('SELECT * FROM wa_sessions WHERE id = ?').get(id) : undefined;
    },

    /** Returns the session ONLY if it belongs to this Telegram user. Use this for every user action. */
    getOwned(id, telegramIdInput) {
      const telegramId = normalizeTelegramId(telegramIdInput);
      if (!telegramId || !isValidSessionId(id)) return undefined;
      return db.prepare('SELECT * FROM wa_sessions WHERE id = ? AND owner_telegram_id = ?').get(id, telegramId);
    },

    listByOwner(telegramIdInput) {
      const telegramId = normalizeTelegramId(telegramIdInput);
      return telegramId
        ? db.prepare('SELECT * FROM wa_sessions WHERE owner_telegram_id = ? ORDER BY created_at').all(telegramId)
        : [];
    },

    listAll() {
      return db.prepare('SELECT * FROM wa_sessions ORDER BY created_at').all();
    },

    /**
     * Reserves one pairing slot and creates the session with default settings.
     * The capacity check and the insert happen in ONE transaction, so two people
     * pairing at the same moment can never go over the limit.
     */
    reserve(ownerTelegramIdInput, label = '') {
      const ownerId = normalizeTelegramId(ownerTelegramIdInput);
      if (!ownerId) return { ok: false, reason: 'invalid_owner' };

      return withTransaction(db, () => {
        if (!db.prepare('SELECT 1 FROM telegram_users WHERE telegram_id = ?').get(ownerId)) {
          return { ok: false, reason: 'unknown_user' };
        }
        const used = repo.count();
        const capacity = getCapacity();
        if (used >= capacity) return { ok: false, reason: 'capacity_full', used, capacity };

        const id = `wa_${crypto.randomBytes(6).toString('hex')}`;
        db.prepare('INSERT INTO wa_sessions (id, owner_telegram_id, label) VALUES (?, ?, ?)')
          .run(id, ownerId, String(label).slice(0, 40));
        db.prepare('INSERT INTO session_settings (session_id, prefix) VALUES (?, ?)').run(id, defaultPrefix);
        return { ok: true, session: repo.get(id), used: used + 1, capacity };
      });
    },

    setStatus(id, status) {
      if (!isValidSessionId(id) || !STATUSES.includes(status)) return false;
      const connectedStamp = status === 'connected' ? ", last_connected_at = datetime('now')" : '';
      return db.prepare(
        `UPDATE wa_sessions SET status = ?, updated_at = datetime('now')${connectedStamp} WHERE id = ?`,
      ).run(status, id).changes > 0;
    },

    setPhone(id, phone) {
      if (!isValidSessionId(id)) return false;
      const digits = String(phone ?? '').replace(/\D/g, '');
      if (!/^\d{7,15}$/.test(digits)) return false;
      return db.prepare("UPDATE wa_sessions SET phone = ?, updated_at = datetime('now') WHERE id = ?")
        .run(digits, id).changes > 0;
    },

    /** Deletes a session row (settings are removed automatically). Auth files are removed in Part 4. */
    remove(id) {
      return isValidSessionId(id) && db.prepare('DELETE FROM wa_sessions WHERE id = ?').run(id).changes > 0;
    },

    /** Only deletes if the session belongs to this user. */
    removeOwned(id, telegramIdInput) {
      const telegramId = normalizeTelegramId(telegramIdInput);
      if (!telegramId || !isValidSessionId(id)) return false;
      return db.prepare('DELETE FROM wa_sessions WHERE id = ? AND owner_telegram_id = ?').run(id, telegramId).changes > 0;
    },

    /** Pairing timeout: frees slots held by pairings that never finished. Returns the removed IDs. */
    expireStalePairings(minutes) {
      const age = `-${Math.max(1, Math.floor(Number(minutes) || 0))} minutes`;
      return withTransaction(db, () => {
        const stale = db.prepare(
          "SELECT id FROM wa_sessions WHERE status IN ('pending','pairing') AND created_at < datetime('now', ?)",
        ).all(age).map((row) => row.id);
        for (const id of stale) db.prepare('DELETE FROM wa_sessions WHERE id = ?').run(id);
        return stale;
      });
    },
  };
  return repo;
}
