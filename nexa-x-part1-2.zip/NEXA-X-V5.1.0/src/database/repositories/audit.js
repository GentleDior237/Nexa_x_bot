export function createAuditRepository(db) {
  return {
    log({ actor, action, target = null, details = null }) {
      db.prepare('INSERT INTO audit_log (actor, action, target, details) VALUES (?, ?, ?, ?)').run(
        String(actor),
        String(action).slice(0, 80),
        target === null ? null : String(target).slice(0, 200),
        details === null ? null : String(details).slice(0, 1000),
      );
    },
    recent(limit = 20) {
      return db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT ?').all(Math.min(Number(limit) || 20, 200));
    },
  };
}
