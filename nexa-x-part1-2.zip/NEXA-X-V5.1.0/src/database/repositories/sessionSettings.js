import { isValidSessionId } from './sessions.js';
import { validatePrefix, validateMenuStyle } from '../../utils/validators.js';
import { normalizeTelegramId } from '../../utils/identity.js';

// Only these columns can be changed. Anything else is rejected.
const EDITABLE = {
  prefix: (v) => validatePrefix(v),
  menu_style: (v) => validateMenuStyle(v),
  bot_name: (v) => {
    const name = String(v ?? '').trim();
    return name.length >= 1 && name.length <= 40
      ? { ok: true, value: name }
      : { ok: false, reason: 'Bot name must be 1-40 characters.' };
  },
  font: (v) => {
    const font = String(v ?? '').trim().toLowerCase();
    return /^[a-z0-9_-]{1,30}$/.test(font)
      ? { ok: true, value: font }
      : { ok: false, reason: 'Invalid font name.' };
  },
  menu_image: (v) => (v === null ? { ok: true, value: null } : { ok: true, value: String(v).slice(0, 300) }),
  menu_audio: (v) => ({ ok: true, value: v ? 1 : 0 }),
};

export function createSessionSettingsRepository(db, { defaultPrefix }) {
  const repo = {
    get(sessionId) {
      return isValidSessionId(sessionId)
        ? db.prepare('SELECT * FROM session_settings WHERE session_id = ?').get(sessionId)
        : undefined;
    },

    /** Changes one or more settings of ONE session. Callers must have already proven ownership. */
    update(sessionId, patch) {
      if (!repo.get(sessionId)) return { ok: false, reason: 'Session not found.' };

      const sets = [];
      const values = [];
      for (const [key, rawValue] of Object.entries(patch)) {
        const check = EDITABLE[key];
        if (!check) return { ok: false, reason: `"${key}" cannot be changed.` };
        const result = check(rawValue);
        if (!result.ok) return result;
        sets.push(`${key} = ?`);
        values.push(result.value);
      }
      if (sets.length === 0) return { ok: false, reason: 'Nothing to change.' };

      db.prepare(`UPDATE session_settings SET ${sets.join(', ')}, updated_at = datetime('now') WHERE session_id = ?`)
        .run(...values, sessionId);
      return { ok: true, settings: repo.get(sessionId) };
    },

    /** Same as update, but refuses unless the session belongs to this Telegram user. */
    updateOwned(sessionId, telegramIdInput, patch) {
      const telegramId = normalizeTelegramId(telegramIdInput);
      const owned = telegramId && isValidSessionId(sessionId)
        && db.prepare('SELECT 1 FROM wa_sessions WHERE id = ? AND owner_telegram_id = ?').get(sessionId, telegramId);
      return owned ? repo.update(sessionId, patch) : { ok: false, reason: 'Session not found.' };
    },

    resetPrefix(sessionId) {
      return repo.update(sessionId, { prefix: defaultPrefix });
    },
  };
  return repo;
}
