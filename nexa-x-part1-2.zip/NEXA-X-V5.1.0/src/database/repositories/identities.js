import { withTransaction } from '../index.js';
import { normalizeTelegramId, normalizeWhatsAppJid } from '../../utils/identity.js';

export function createIdentityRepository(db) {
  return {
    /**
     * Links a Telegram account and a WhatsApp identity.
     * Both must already exist in their user tables.
     * Each side can only be linked once (UNIQUE in the database).
     */
    link(telegramIdInput, jidInput) {
      const telegramId = normalizeTelegramId(telegramIdInput);
      const jid = normalizeWhatsAppJid(jidInput);
      if (!telegramId || !jid) return { ok: false, reason: 'invalid_id' };

      return withTransaction(db, () => {
        const tgExists = db.prepare('SELECT 1 FROM telegram_users WHERE telegram_id = ?').get(telegramId);
        const waExists = db.prepare('SELECT 1 FROM whatsapp_users WHERE jid = ?').get(jid);
        if (!tgExists || !waExists) return { ok: false, reason: 'unknown_user' };

        const taken = db.prepare(
          'SELECT telegram_id, whatsapp_jid FROM linked_identities WHERE telegram_id = ? OR whatsapp_jid = ?',
        ).get(telegramId, jid);
        if (taken) {
          return taken.telegram_id === telegramId && taken.whatsapp_jid === jid
            ? { ok: true, alreadyLinked: true }
            : { ok: false, reason: 'already_linked_to_someone_else' };
        }

        db.prepare('INSERT INTO linked_identities (telegram_id, whatsapp_jid) VALUES (?, ?)').run(telegramId, jid);
        return { ok: true };
      });
    },

    unlinkByTelegram(telegramIdInput) {
      const telegramId = normalizeTelegramId(telegramIdInput);
      if (!telegramId) return false;
      return db.prepare('DELETE FROM linked_identities WHERE telegram_id = ?').run(telegramId).changes > 0;
    },

    findByTelegram(telegramIdInput) {
      const telegramId = normalizeTelegramId(telegramIdInput);
      return telegramId
        ? db.prepare('SELECT * FROM linked_identities WHERE telegram_id = ?').get(telegramId)
        : undefined;
    },

    findByWhatsApp(jidInput) {
      const jid = normalizeWhatsAppJid(jidInput);
      return jid
        ? db.prepare('SELECT * FROM linked_identities WHERE whatsapp_jid = ?').get(jid)
        : undefined;
    },
  };
}
