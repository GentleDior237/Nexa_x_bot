import { createUserRepositories } from './users.js';
import { createIdentityRepository } from './identities.js';
import { createGlobalSettingsRepository } from './globalSettings.js';
import { createAuditRepository } from './audit.js';
import { createSessionRepository } from './sessions.js';
import { createSessionSettingsRepository } from './sessionSettings.js';

/** Builds every repository from one open database. */
export function createRepositories(db, config) {
  const globalSettings = createGlobalSettingsRepository(db, { defaultCapacity: config.whatsapp.maxSessions });
  const users = createUserRepositories(db);
  const sessions = createSessionRepository(db, {
    getCapacity: () => globalSettings.getPairingCapacity(),
    defaultPrefix: config.whatsapp.prefix,
  });
  return {
    telegramUsers: users.telegram,
    whatsappUsers: users.whatsapp,
    identities: createIdentityRepository(db),
    globalSettings,
    audit: createAuditRepository(db),
    sessions,
    sessionSettings: createSessionSettingsRepository(db, { defaultPrefix: config.whatsapp.prefix }),
  };
}
