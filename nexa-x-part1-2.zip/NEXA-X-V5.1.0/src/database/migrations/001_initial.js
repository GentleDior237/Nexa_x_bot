// Migration 001: the first set of tables (Part 2).
// Later parts add NEW migration files (002, 003, ...). Never edit an applied one.

export default {
  id: 1,
  name: 'initial_schema',
  up(db) {
    db.exec(`
      CREATE TABLE telegram_users (
        telegram_id TEXT PRIMARY KEY,
        first_name  TEXT NOT NULL DEFAULT '',
        username    TEXT,
        tokens      INTEGER NOT NULL DEFAULT 0 CHECK (tokens >= 0),
        first_seen  TEXT NOT NULL DEFAULT (datetime('now')),
        last_seen   TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE whatsapp_users (
        jid        TEXT PRIMARY KEY,
        phone      TEXT,
        push_name  TEXT,
        first_seen TEXT NOT NULL DEFAULT (datetime('now')),
        last_seen  TEXT NOT NULL DEFAULT (datetime('now'))
      );

      -- One Telegram account <-> one WhatsApp identity. Used by the ban system in Part 9.
      CREATE TABLE linked_identities (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id  TEXT NOT NULL UNIQUE REFERENCES telegram_users(telegram_id) ON DELETE CASCADE,
        whatsapp_jid TEXT NOT NULL UNIQUE REFERENCES whatsapp_users(jid) ON DELETE CASCADE,
        linked_at    TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE wa_sessions (
        id                TEXT PRIMARY KEY CHECK (id GLOB 'wa_[0-9a-f]*'),
        owner_telegram_id TEXT NOT NULL REFERENCES telegram_users(telegram_id) ON DELETE CASCADE,
        label             TEXT NOT NULL DEFAULT '',
        phone             TEXT,
        status            TEXT NOT NULL DEFAULT 'pending'
                          CHECK (status IN ('pending','pairing','connected','disconnected')),
        created_at        TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at        TEXT NOT NULL DEFAULT (datetime('now')),
        last_connected_at TEXT
      );
      CREATE INDEX idx_sessions_owner  ON wa_sessions(owner_telegram_id);
      CREATE INDEX idx_sessions_status ON wa_sessions(status);

      -- Every WhatsApp session has its OWN settings row.
      CREATE TABLE session_settings (
        session_id TEXT PRIMARY KEY REFERENCES wa_sessions(id) ON DELETE CASCADE,
        prefix     TEXT NOT NULL,
        bot_name   TEXT,
        menu_style TEXT NOT NULL DEFAULT 'cyber',
        font       TEXT NOT NULL DEFAULT 'normal',
        menu_image TEXT,
        menu_audio INTEGER NOT NULL DEFAULT 1 CHECK (menu_audio IN (0,1)),
        extra_json TEXT NOT NULL DEFAULT '{}',
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE global_settings (
        key        TEXT PRIMARY KEY,
        value      TEXT NOT NULL,
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE audit_log (
        id      INTEGER PRIMARY KEY AUTOINCREMENT,
        at      TEXT NOT NULL DEFAULT (datetime('now')),
        actor   TEXT NOT NULL,
        action  TEXT NOT NULL,
        target  TEXT,
        details TEXT
      );
      CREATE INDEX idx_audit_at ON audit_log(at);
    `);
  },
};
