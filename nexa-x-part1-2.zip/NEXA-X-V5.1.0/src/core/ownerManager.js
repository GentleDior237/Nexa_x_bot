import { normalizeTelegramId, phoneFromJid } from '../utils/identity.js';

/**
 * The Owner is defined ONLY by .env (OWNER_TELEGRAM_ID / OWNER_WHATSAPP_NUMBER).
 * Nothing in the database or in a chat message can make someone the Owner.
 */
export function createOwnerManager(config) {
  return {
    isOwnerTelegram(id) {
      const telegramId = normalizeTelegramId(id);
      return Boolean(telegramId) && telegramId === config.telegram.ownerId;
    },

    /**
     * Matches by phone number. WhatsApp sometimes shows people as "@lid" IDs that hide the
     * phone number; those cannot be matched here. Part 5 resolves them through the session.
     */
    isOwnerWhatsApp(jid) {
      const phone = phoneFromJid(jid);
      return Boolean(phone) && Boolean(config.whatsapp.ownerNumber) && phone === config.whatsapp.ownerNumber;
    },
  };
}
