import 'dotenv/config';
import path from 'node:path';

const root = process.cwd();

function text(name, fallback = '') {
  const value = process.env[name];
  return value === undefined || value.trim() === '' ? fallback : value.trim();
}

function whole(name, fallback) {
  const value = Number.parseInt(process.env[name] ?? '', 10);
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

export const config = Object.freeze({
  bot: {
    name: text('BOT_NAME', 'NEXA X V5.1.0'),
    version: text('BOT_VERSION', '5.1.0'),
    edition: 'CYBER EDITION',
    tagline: 'Your WhatsApp. Your Power. Your Control.',
  },
  developer: {
    name: text('DEVELOPER_NAME', 'MR DIOR CYBER'),
    contact: text('DEVELOPER_CONTACT', 'https://t.me/Bigleem247'),
  },
  telegram: {
    token: text('TELEGRAM_BOT_TOKEN'),
    ownerId: text('OWNER_TELEGRAM_ID'),
    prefix: text('TELEGRAM_DEFAULT_PREFIX', '/'),
  },
  whatsapp: {
    ownerNumber: text('OWNER_WHATSAPP_NUMBER').replace(/\D/g, ''),
    prefix: text('WHATSAPP_DEFAULT_PREFIX', '.'),
    maxSessions: whole('MAX_SESSIONS', 100),
  },
  paths: {
    database: path.resolve(root, text('DATABASE_PATH', './data/nexa.sqlite')),
    sessions: path.resolve(root, text('SESSIONS_PATH', './sessions')),
    media: path.resolve(root, text('MEDIA_PATH', './data/media')),
    backups: path.resolve(root, text('BACKUP_PATH', './backups')),
    logs: path.resolve(root, text('LOG_PATH', './logs')),
  },
  env: text('NODE_ENV', 'production'),
});

/** Returns a list of problems. An empty list means the config is usable. */
export function validateConfig() {
  const problems = [];
  if (!config.telegram.token) problems.push('TELEGRAM_BOT_TOKEN is missing.');
  if (!/^\d+$/.test(config.telegram.ownerId)) {
    problems.push('OWNER_TELEGRAM_ID must be a numeric Telegram ID.');
  }
  return problems;
}
