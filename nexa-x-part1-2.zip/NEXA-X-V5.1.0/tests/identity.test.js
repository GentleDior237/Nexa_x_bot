import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeTelegramId, normalizeWhatsAppJid, phoneFromJid } from '../src/utils/identity.js';
import { validatePrefix } from '../src/utils/validators.js';
import { createOwnerManager } from '../src/core/ownerManager.js';

test('telegram IDs must be digits only', () => {
  assert.equal(normalizeTelegramId(' 12345 '), '12345');
  assert.equal(normalizeTelegramId('@someone'), null);
  assert.equal(normalizeTelegramId('12a'), null);
});

test('WhatsApp IDs are normalised to one form', () => {
  assert.equal(normalizeWhatsAppJid('+234 801 234 5678'), '2348012345678@c.us');
  assert.equal(normalizeWhatsAppJid('2348012345678@s.whatsapp.net'), '2348012345678@c.us');
  assert.equal(normalizeWhatsAppJid('2348012345678:12@c.us'), '2348012345678@c.us');
  assert.equal(normalizeWhatsAppJid('123456789012@lid'), '123456789012@lid');
  assert.equal(normalizeWhatsAppJid('Mr Dior'), null);
  assert.equal(normalizeWhatsAppJid('abc@evil.com'), null);
  assert.equal(phoneFromJid('2348012345678:3@s.whatsapp.net'), '2348012345678');
  assert.equal(phoneFromJid('123456789012@lid'), null);
});

test('prefix validation blocks letters, digits, spaces and formatting characters', () => {
  assert.equal(validatePrefix('!').ok, true);
  assert.equal(validatePrefix('#').ok, true);
  for (const bad of ['', 'a', '1', ' ', '*', '_', '`', '@', 'abc', '!!!']) {
    assert.equal(validatePrefix(bad).ok, false, `"${bad}" should be rejected`);
  }
});

test('owner is verified by numeric ID / phone number only', () => {
  const owner = createOwnerManager({ telegram: { ownerId: '111' }, whatsapp: { ownerNumber: '2348000000001' } });
  assert.equal(owner.isOwnerTelegram(111), true);
  assert.equal(owner.isOwnerTelegram('112'), false);
  assert.equal(owner.isOwnerTelegram('@owner'), false);
  assert.equal(owner.isOwnerWhatsApp('2348000000001:5@s.whatsapp.net'), true);
  assert.equal(owner.isOwnerWhatsApp('2348000000002@c.us'), false);
});

test('owner check fails closed when no WhatsApp owner number is set', () => {
  const owner = createOwnerManager({ telegram: { ownerId: '111' }, whatsapp: { ownerNumber: '' } });
  assert.equal(owner.isOwnerWhatsApp('2348000000001@c.us'), false);
});
