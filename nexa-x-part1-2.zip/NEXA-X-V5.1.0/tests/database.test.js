import test from 'node:test';
import assert from 'node:assert/strict';
import { freshDb } from './helpers/db.js';
import { runMigrations } from '../src/database/index.js';

async function setup() {
  const ctx = await freshDb();
  ctx.repos.telegramUsers.upsert({ id: 111, firstName: 'Owner' });
  ctx.repos.telegramUsers.upsert({ id: 222, firstName: 'Alice' });
  ctx.repos.telegramUsers.upsert({ id: 333, firstName: 'Bob' });
  return ctx;
}

test('migrations run once and are safe to repeat', async () => {
  const { db } = await freshDb();
  assert.deepEqual(await runMigrations(db), []);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM schema_migrations').get().n, 1);
});

test('telegram user upsert refreshes the name but keeps tokens', async () => {
  const { repos } = await setup();
  const again = repos.telegramUsers.upsert({ id: 222, firstName: 'Alicia', username: 'ali' });
  assert.equal(again.first_name, 'Alicia');
  assert.equal(again.tokens, 0);
  assert.equal(repos.telegramUsers.count(), 3);
  assert.throws(() => repos.telegramUsers.upsert({ id: 'bad' }));
});

test('linking identities: one-to-one only', async () => {
  const { repos } = await setup();
  repos.whatsappUsers.upsert({ jid: '2348010000001' });
  repos.whatsappUsers.upsert({ jid: '2348010000002' });
  assert.equal(repos.identities.link(222, '2348010000001@c.us').ok, true);
  assert.equal(repos.identities.link(222, '2348010000001@c.us').alreadyLinked, true);
  assert.equal(repos.identities.link(333, '2348010000001@c.us').reason, 'already_linked_to_someone_else');
  assert.equal(repos.identities.link(222, '2348010000002@c.us').reason, 'already_linked_to_someone_else');
  assert.equal(repos.identities.findByWhatsApp('2348010000001:7@s.whatsapp.net').telegram_id, '222');
  assert.equal(repos.identities.link(999, '2348010000001@c.us').reason, 'unknown_user');
});

test('pairing capacity is enforced and slots are freed on delete', async () => {
  const { repos } = await setup(); // capacity = 2
  const a = repos.sessions.reserve(222);
  const b = repos.sessions.reserve(333);
  const c = repos.sessions.reserve(222);
  assert.equal(a.ok && b.ok, true);
  assert.equal(c.ok, false);
  assert.equal(c.reason, 'capacity_full');
  assert.equal(repos.sessions.count(), 2);

  repos.sessions.remove(a.session.id);
  assert.equal(repos.sessions.reserve(222).ok, true);
});

test('owner can change capacity; invalid values are refused', async () => {
  const { repos } = await setup();
  assert.equal(repos.globalSettings.getPairingCapacity(), 2);
  assert.equal(repos.globalSettings.setPairingCapacity(150).ok, true);
  assert.equal(repos.globalSettings.getPairingCapacity(), 150);
  assert.equal(repos.globalSettings.adjustPairingCapacity(-20).capacity, 130);
  assert.equal(repos.globalSettings.setPairingCapacity(-1).ok, false);
  assert.equal(repos.globalSettings.setPairingCapacity('abc').ok, false);
  assert.equal(repos.globalSettings.adjustPairingCapacity(-9999).ok, false);
});

test('session settings are isolated between sessions', async () => {
  const { repos } = await setup();
  const a = repos.sessions.reserve(222).session;
  const b = repos.sessions.reserve(333).session;
  assert.equal(repos.sessionSettings.updateOwned(a.id, 222, { prefix: '!', menu_style: 'box' }).ok, true);
  assert.equal(repos.sessionSettings.get(a.id).prefix, '!');
  assert.equal(repos.sessionSettings.get(b.id).prefix, '.');
  assert.equal(repos.sessionSettings.get(b.id).menu_style, 'cyber');
});

test('a user cannot read, change or delete another user\'s session', async () => {
  const { repos } = await setup();
  const a = repos.sessions.reserve(222).session;
  assert.equal(repos.sessions.getOwned(a.id, 333), undefined);
  assert.equal(repos.sessions.getOwned(a.id, 222).id, a.id);
  assert.equal(repos.sessionSettings.updateOwned(a.id, 333, { prefix: '#' }).ok, false);
  assert.equal(repos.sessions.removeOwned(a.id, 333), false);
  assert.equal(repos.sessionSettings.get(a.id).prefix, '.');
  assert.equal(repos.sessions.removeOwned(a.id, 222), true);
});

test('settings reject bad values and unknown fields', async () => {
  const { repos } = await setup();
  const a = repos.sessions.reserve(222).session;
  assert.equal(repos.sessionSettings.update(a.id, { prefix: 'ab1' }).ok, false);
  assert.equal(repos.sessionSettings.update(a.id, { menu_style: 'weird' }).ok, false);
  assert.equal(repos.sessionSettings.update(a.id, { session_id: 'wa_000000000000' }).ok, false);
  assert.equal(repos.sessionSettings.update(a.id, { prefix: "'; DROP TABLE wa_sessions;--" }).ok, false);
  assert.equal(repos.sessionSettings.get(a.id).prefix, '.');
  assert.equal(repos.sessionSettings.resetPrefix(a.id).ok, true);
});

test('session IDs are strictly checked (no path tricks)', async () => {
  const { repos } = await setup();
  assert.equal(repos.sessions.get('../../etc/passwd'), undefined);
  assert.equal(repos.sessions.remove('wa_x'), false);
});

test('deleting a session removes its settings; deleting a user removes their sessions', async () => {
  const { db, repos } = await setup();
  const a = repos.sessions.reserve(222).session;
  db.prepare('DELETE FROM telegram_users WHERE telegram_id = ?').run('222');
  assert.equal(repos.sessions.get(a.id), undefined);
  assert.equal(repos.sessionSettings.get(a.id), undefined);
});

test('stale unfinished pairings are expired, connected ones are kept', async () => {
  const { db, repos } = await setup();
  const stale = repos.sessions.reserve(222).session;
  const live = repos.sessions.reserve(333).session;
  repos.sessions.setStatus(live.id, 'connected');
  db.prepare("UPDATE wa_sessions SET created_at = datetime('now','-10 minutes')").run();
  const removed = repos.sessions.expireStalePairings(3);
  assert.deepEqual(removed, [stale.id]);
  assert.equal(repos.sessions.get(live.id).status, 'connected');
});

test('failed transaction rolls back everything', async () => {
  const { db, repos } = await setup();
  const { withTransaction } = await import('../src/database/index.js');
  assert.throws(() => withTransaction(db, () => {
    repos.sessions.reserve(222);
    throw new Error('boom');
  }));
  assert.equal(repos.sessions.count(), 0);
});

test('audit log records actions', async () => {
  const { repos } = await setup();
  repos.audit.log({ actor: '111', action: 'capacity_changed', target: 'global', details: '2 -> 150' });
  assert.equal(repos.audit.recent(1)[0].action, 'capacity_changed');
});
