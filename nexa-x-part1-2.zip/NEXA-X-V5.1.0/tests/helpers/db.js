// Tests use Node's built-in SQLite so they run without installing anything.
// It has the same prepare/run/get/all/exec methods that the app uses from better-sqlite3.
import { DatabaseSync } from 'node:sqlite';
import { runMigrations } from '../../src/database/index.js';
import { createRepositories } from '../../src/database/repositories/index.js';

export async function freshDb(overrides = {}) {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  await runMigrations(db);
  const config = {
    telegram: { ownerId: '111' },
    whatsapp: { prefix: '.', maxSessions: 2, ownerNumber: '2348000000001', ...overrides },
  };
  return { db, config, repos: createRepositories(db, config) };
}
