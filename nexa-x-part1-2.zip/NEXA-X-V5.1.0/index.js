import fs from 'node:fs';
import path from 'node:path';
import { config, validateConfig } from './src/config/index.js';
import { openDatabase, runMigrations } from './src/database/index.js';
import { createRepositories } from './src/database/repositories/index.js';
import { createOwnerManager } from './src/core/ownerManager.js';

let db = null;

function banner() {
  console.log('==============================================');
  console.log(` ${config.bot.name} - ${config.bot.edition}`);
  console.log(` ${config.bot.tagline}`);
  console.log(` Developer: ${config.developer.name}`);
  console.log('==============================================');
}

function ensureFolders() {
  const { database, ...folders } = config.paths;
  for (const folder of [path.dirname(database), ...Object.values(folders)]) {
    fs.mkdirSync(folder, { recursive: true });
  }
}

async function main() {
  banner();

  const problems = validateConfig();
  if (problems.length > 0) {
    console.error('Configuration problems found:');
    for (const problem of problems) console.error(` - ${problem}`);
    console.error('Copy .env.example to .env and fill it in, then start again.');
    process.exit(1);
  }

  ensureFolders();

  db = await openDatabase(config.paths.database);
  const applied = await runMigrations(db);
  console.log(applied.length ? `Database updated: ${applied.join(', ')}` : 'Database is up to date.');

  const repos = createRepositories(db, config);
  const owner = createOwnerManager(config);

  console.log(`Owner (Telegram): ${owner.isOwnerTelegram(config.telegram.ownerId) ? 'verified from .env' : 'NOT valid'}`);
  console.log(`Pairing capacity: ${repos.sessions.count()} used / ${repos.globalSettings.getPairingCapacity()} allowed`);
  console.log('Part 2 OK: database and identity are ready.');
  console.log('The Telegram bot and WhatsApp sessions arrive in Parts 3-4.');
}

function shutdown(signal) {
  console.log(`Received ${signal}. Shutting down.`);
  try { db?.close(); } catch { /* already closed */ }
  process.exit(0);
}
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => shutdown(signal));

main().catch((error) => {
  console.error('Startup failed:', error.message);
  process.exit(1);
});
